<template>
  <v-app>
    <HeaderEcom/>
    <CategoryCont v-if="isCat"/>
    <SellerHome v-if="isSeller"/>
    <DashBoard v-if="isDash"/>
    <router-view :key="$route.path" />
    <FooterEcom class="mt-15"/>
  </v-app>
</template>
<script>
import HeaderEcom from '../src/components/Header.vue'
import FooterEcom from '../src/components/Footer.vue'
import DashBoard from '../src/components/Dashboard.vue'
import CategoryCont from './components/CategoryLinks.vue'
import SellerHome from './components/SellerHome.vue'

export default {
  name: "App",
  data: () => ({
    auth:[],
  }),
  components: {
    HeaderEcom,
    FooterEcom,
    DashBoard,
    CategoryCont,
    SellerHome,
  },
  created(){
    this.auth=JSON.parse(localStorage.getItem("auth"));
    // console.log(this.auth);
  },
  
  computed:{
    isDash(){
      if(this.$route.name=="/" || this.$route.name==null){
        if(this.auth?.userType!=="SELLER")
          return true
        else
          return false
      }
      else
        return false
    },
    isCat(){
      if(this.$route.name==="/" || this.$route.name===null || this.$route.name==="Categories"){
        if(this.auth?.userType!=="SELLER")
          return true
        else
          return false
      }
      else
        return false
    },
    isSeller(){
      if(this.auth?.userType==='SELLER' && this.$route.name==null)
        return true
      else
        return false
    }
  }
};
</script>