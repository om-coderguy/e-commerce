<template>
  <div class="dummy-data">
    Lorem, ipsum dolor sit amet consectetur adipisicing elit. Aliquid dicta nemo blanditiis commodi officia placeat quas id accusamus sit labore debitis delectus ab unde expedita et odit, consequatur quibusdam. Facilis.
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>