<template>
  <div id="footer">
    <v-footer class="footer pa-6">
      <ul class="flex-container">
        <li class="links">
          About
          <ol>
            <li class="about">About Us</li>
            <li class="about">Carrers</li>
          </ol>
        </li>

        <li class="links">
          Connect with Us
          <ol>
            <li class="connect">Facebook</li>
            <li class="connect">Twitter</li>
            <li class="connect">Instagram</li>
          </ol>
        </li>

        <li class="links">
          Support
          <ol>
            <li class="support">Account</li>
            <li class="support">Orders</li>
          </ol>
        </li>

        <li class="links">
          Make money with Us
          <ol>
            <li class="money">Register seller</li>
            <li class="money">Add product in seller</li>
          </ol>
        </li>
      </ul>
    </v-footer>
  </div>
</template>

<script>
export default {
  data:()=>({

  }),
  name: "FooterEcom",
  methods:{
  }
};
</script>

<style>
.footer {
  flex: none;
  box-shadow: 0px 2px 4px -1px rgba(0, 0, 0, 0.2),
    0px 4px 5px 0px rgba(0, 0, 0, 0.14), 0px 1px 10px 0px rgba(0, 0, 0, 0.12);
}

.flex-container {
  width: 90%;
  margin: auto;
  display: flex;
  justify-content: space-between;
}
</style>