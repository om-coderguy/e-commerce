<template>
  <div class="home-page">
    <v-btn text class="green lighten-3 outlined ma-2" @click="pageName = 'add'">
      Manage Inventory
    </v-btn>

    <v-btn
      text
      class="green lighten-3 outlined ma-2"
      @click="openProductPage"
    >
      My Products
    </v-btn>
    <div class="main-box">
      <AddProductForm  v-if="pageName == 'add'" style="width:35%;margin:auto"/>
      <SellersProduct v-if="pageName == 'products'" />
    </div>
  </div>
</template>

<script>
import AddProductForm from './AddProductForm.vue'
import SellersProduct from './SellersProduct.vue'

export default {
  data: () => ({
    pageName: "",    
  }),
  components:{
    AddProductForm,
    SellersProduct
  },
  methods: {
    openProductPage() {
      this.pageName='products'
    },   
  },
};
</script>

<style>
</style>