import Vue from 'vue'
import Router from 'vue-router'
// import HeaderEcom from '../components/Header'
// import DashBoard from '../components/Dashboard'
import NavDrawer from '../components/NavDrawer'
import CategoryContent from '../components/CategoryContent.vue'
import CartProducts from '../components/CartProducts.vue'
import UserOrders from '../components/UserOrders.vue'

Vue.use(Router)

export default new Router({
  routes: [
    // {vue
    //   path: '/',
    //   name: 'Dashboard',
    //   component: DashBoard
    // },
    {
      path: '/nav',
      name: 'NavDrawer',
      component: NavDrawer
    },
    {
      path: '/category/:id',
      name: 'Categories',
      component: CategoryContent
    },
    {
      path: '/cart',
      name: 'Cart',
      component: CartProducts
    },
    {
      path: '/orders',
      name: 'Orders',
      component: UserOrders
    },
  ]
})
